#!/bin/bash

#
gnuplot --version >> "/dev/null"

if [ $? -ne 0 ] 
then
    echo "Error: Cannot invoke GNUPLOT"
    exit 1
fi

#
dir="data_runs_ham"
mkdir -p $dir $dir"/logs"

#
cp "plot_ham_all_gcc.gp" $dir

#
for compiler in "gcc"
do
    echo "Compiler used : "$compiler

    #Compiler optimizations
    for opt in "O1" "O2" "O3" "Ofast"
    do
        #
        echo "Running with flag: "$opt
        
        #
        mkdir -p $dir"/"$compiler"_"$opt
        mkdir -p $dir"/"$compiler"_"$opt"/data"

        #
        cp "plot_ham.gp" $dir"/"$compiler"_"$opt
        
        #Going through code variants
        for variant in ham_baseline ham_baseline_up
        do
            str1="x"
            str2="y"
        	#
        	echo -e "\tVariant: "$variant
        	#Compile variant
            make $variant CC=$compiler O=$opt >> $dir"/logs/compile.log" 2>> $dir"/logs/compile_err.log"
            for cpt in `seq 1 12`
            do
                ./ham $str1 $str2 >> $dir"/"$compiler"_"$opt"/data/"$variant
                str1+=x
                str2+=y
            done

        echo
        done

        #
        cd $dir"/"$compiler"_"$opt

        #Generate the plot
        gnuplot -c "plot_ham.gp" > "plot_"$opt".png"
        
        cd ../..

        echo
    done
done

#
cd $dir

gnuplot -c "plot_ham_all_gcc.gp" > "plot_all_gcc.png" 

cd ..

#
make clean

#
echo -e "\n[DONE]"