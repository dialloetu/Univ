/*
 ============================================================================
 Name        : hamming.c
 Author      : diallo
 Version     : gcc
 Copyright   : 2021 AVP
 Description : This code performs for hamming distance computing
 ============================================================================
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>
#include "rdtsc.h"


// version standard
int ham_baseline(char* str1, char* str2, int m, int n)
{
    int i=0, res=0;
    if (m == n)
    {
        for (i = 0; i < m; ++i)
        {
            if (str1[i] != str2[i])
                res++;
        }
    }

    return res;

}


//
int main(int argc, char **argv)
{
	

	if (argc < 3)
		return printf("Usage: %s [str1] [str2]\n", argv[0]), 1;

	char* str1 = strdup(argv[1]);
	char* str2 = strdup(argv[2]);
    int len_str1 = strlen(str1), len_str2 = strlen(str2);

	unsigned long long cycles_deb, cycles_fin, timer;

	//Start 
	cycles_deb = rdtsc();

	//other versions here
	#if BASELINE
	      ham_baseline(str1, str2, len_str1, len_str2);
	#endif
	#if BASELINE_UP
	#endif
      
    //Stop
    cycles_fin = rdtsc();

    // computing 
    timer = (cycles_fin - cycles_deb);

    fprintf(stdout, "%20u %20llu\n", (len_str1+len_str2), timer);
  
    //
    free(str1);
    free(str2);


    return EXIT_SUCCESS;
}
