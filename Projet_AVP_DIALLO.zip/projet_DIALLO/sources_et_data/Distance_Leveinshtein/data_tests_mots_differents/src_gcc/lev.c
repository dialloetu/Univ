/*
 ============================================================================
 Name        : leveinshtein.c
 Author      : diallo
 Version     : gcc
 Copyright   : 2021 AVP
 Description : This code performs for leveinshtein distance computing
 ============================================================================
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>
#include "rdtsc.h"


static inline int MIN(int a, int b, int c) 
{
	return ((a) < (b) && (a) < (c) ? a : ((b) < (c) ? b : c));
}


// version reccursive
int lev_baseline(char* str1, char* str2, int m, int n)
{
    if (m == 0)
        return n;

    if (n == 0)
        return m;

    if (str1[m - 1] == str2[n - 1])
        return lev_baseline(str1, str2, m - 1, n - 1);

    return 1 + MIN(lev_baseline(str1, str2, m, n - 1),
                   lev_baseline(str1, str2, m - 1, n),
                   lev_baseline(str1, str2, m - 1, n - 1)
                );
}

// version itérative
int lev_baseline_up(char* str1, char* str2, int m, int n)
{
    // tableau pour stocker les résultats des sous-problèmes
    int dp[m + 1][n + 1];
    int i, j;

    for (i = 0; i <= m; i++)
    {
        for (j = 0; j <= n; j++)
        {
            // Si la première chaîne est vide, la seule l'option est d'insère tous les caractères de la deuxième chaîne
            if (i == 0)
                dp[i][j] = j;
            else if (j == 0)
                dp[i][j] = i;
            // Si la deuxième chaîne est vide, seule l'option est de supprime tous les caractères de la deuxième chaîne
            else if (str1[i - 1] == str2[j - 1])
                dp[i][j] = dp[i - 1][j - 1];
            else
                dp[i][j]
                    = 1 + MIN(dp[i][j - 1],       // Insertion
                            dp[i - 1][j],          // Suppression
                            dp[i - 1][j - 1]);    // substitution
        }
    }
    return dp[m][n];
}



//
int main(int argc, char **argv)
{
	 
	if (argc < 3)
		return printf("Usage: %s [str1] [str2]\n", argv[0]), 1;

	char* str1 = strdup(argv[1]);
	char* str2 = strdup(argv[2]);
    int len_str1 = strlen(str1), len_str2 = strlen(str2);

	unsigned long long cycles_deb, cycles_fin, timer;

	//Start 
	cycles_deb = rdtsc();

	//other versions here
	#if BASELINE
	      lev_baseline(str1, str2, len_str1, len_str2);
	#endif
	#if BASELINE_UP
	      lev_baseline_up(str1, str2, len_str1, len_str2);
	#endif
      
    //Stop
    cycles_fin = rdtsc();

    // computing 
    timer = (cycles_fin - cycles_deb);

    fprintf(stdout, "%20u %20llu\n", (len_str1+len_str2), timer);
  
    //
    free(str1);
    free(str2);


    return EXIT_SUCCESS;
}
