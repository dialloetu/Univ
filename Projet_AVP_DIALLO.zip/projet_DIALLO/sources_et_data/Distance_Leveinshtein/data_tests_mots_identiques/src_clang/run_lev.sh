#!/bin/bash

#
gnuplot --version >> "/dev/null"

if [ $? -ne 0 ] 
then
    echo "Error: Cannot invoke GNUPLOT"
    exit 1
fi

#
dir="data_runs_lev"
mkdir -p $dir $dir"/logs"

#
cp "plot_lev_all_clang.gp" $dir

#
for compiler in "clang"
do
    echo "Compiler used : "$compiler

    #Compiler optimizations
    for opt in "O1" "O2" "O3" "Ofast"
    do
        #
        echo "Running with flag: "$opt
        
        #
        mkdir -p $dir"/"$compiler"_"$opt
        mkdir -p $dir"/"$compiler"_"$opt"/data"

        #
        cp "plot_lev.gp" $dir"/"$compiler"_"$opt
        
        #Going through code variants
        for variant in lev_baseline lev_baseline_up
        do
            str1="x"
            str2="x"
        	#
        	echo -e "\tVariant: "$variant
        	#Compile variant
            make $variant CC=$compiler O=$opt >> $dir"/logs/compile.log" 2>> $dir"/logs/compile_err.log"
            for cpt in `seq 1 6`
            do
                ./lev $str1 $str2 >> $dir"/"$compiler"_"$opt"/data/"$variant
                str1+=x
                str2+=x
            done

        echo
        done

        #
        cd $dir"/"$compiler"_"$opt

        #Generate the plot
        gnuplot -c "plot_lev.gp" > "plot_"$opt".png"
        
        cd ../..

        echo
    done
done

#
cd $dir

gnuplot -c "plot_lev_all_clang.gp" > "plot_all_clang.png" 

cd ..

#
make clean

#
echo -e "\n[DONE]"