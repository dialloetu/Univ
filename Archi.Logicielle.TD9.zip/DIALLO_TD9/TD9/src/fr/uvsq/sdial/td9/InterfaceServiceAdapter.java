package fr.uvsq.sdial.td9;

import java.rmi.RemoteException;


public class InterfaceServiceAdapter implements InterfaceServiceRemote {

    private InterfaceService service;
	
	public InterfaceServiceAdapter (InterfaceService service) {
		this.service = service;
	}
	
	@Override
	public String hello(String nom) throws RemoteException {
		// TODO Auto-generated method stub
		return service.hello(nom);
	}

}
