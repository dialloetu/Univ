package fr.uvsq.sdial.td9;

public class Main1_Monolithe {

		public static void main (String args[]) {
			ImplementationInterfaceService service = new ImplementationInterfaceService();
			IHM ihm = new IHM();
			ihm.setService(service);
			
			ihm.demarrer(args[0]);
		}
}
