package fr.uvsq.sdial.td9;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class InterfaceServiceProxy implements InterfaceService {

	private Registry registry;
	private InterfaceServiceRemote stub;
	
	public InterfaceServiceProxy() throws RemoteException, NotBoundException {
		registry = LocateRegistry.getRegistry();
		stub = (InterfaceServiceRemote) registry.lookup("Service");
	}
	
	@Override
	public String hello(String nom) {
		// TODO Auto-generated method stub
		try {
			return stub.hello(nom);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return ""; 
		}

	}

}
