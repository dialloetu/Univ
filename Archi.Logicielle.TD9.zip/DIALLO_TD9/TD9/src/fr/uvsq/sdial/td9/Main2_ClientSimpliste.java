package fr.uvsq.sdial.td9;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Main2_ClientSimpliste {
	public static void main (String args[]) {
		try {
		    Registry registry = LocateRegistry.getRegistry();
		    InterfaceServiceRemote stub = (InterfaceServiceRemote) registry.lookup("Service");
		    String response = stub.hello(args[0]);
		    System.out.println(response);
		} catch (Exception e) {
		    System.err.println("Client exception: " + e.toString());
		    e.printStackTrace();
		}
	}

}

