package fr.uvsq.sdial.td9;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface InterfaceServiceRemote extends Remote {

	String hello(String nom) throws RemoteException;

	
}
