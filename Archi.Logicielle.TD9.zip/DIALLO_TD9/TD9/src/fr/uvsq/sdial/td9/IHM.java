package fr.uvsq.sdial.td9;

public class IHM {
	
	private InterfaceService service;

	public void setService(InterfaceService service) {
		this.service = service;
	}



	public void demarrer (String nom) {
		String hello = service.hello(nom);
		System.out.println(hello);
	}
	

}
