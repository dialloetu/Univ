package fr.uvsq.sdial.td9;


public class Main2_ClientStructure {

	public static void main(String[] args) {
		
		InterfaceService service = null;
		
		try {
			service =  new InterfaceServiceProxy();
		    
		} catch (Exception e) {
		    e.printStackTrace();
		}
		
		
		
		IHM ihm = new IHM();
		ihm.setService(service);
		
		ihm.demarrer(args[0]);
	}

}
