package fr.uvsq.sdial.td9;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class Main2_Serveur {

	public static void main(String[] args) {
		
		ImplementationInterfaceService service = new ImplementationInterfaceService();
		InterfaceServiceAdapter adapter = new InterfaceServiceAdapter(service);
		
		try {
            InterfaceServiceRemote stub = (InterfaceServiceRemote) UnicastRemoteObject.exportObject(adapter, 0);

            // Bind the remote object's stub in the registry
            Registry registry = LocateRegistry.createRegistry(1099);
            registry.bind("Service", stub);

            System.err.println("Server ready");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }

	}

}
