package fr.uvsq.sdial.td9;

public interface InterfaceService {
	String hello(String nom);

}
