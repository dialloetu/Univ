package fr.uvsq.sdial.td9;

public class ImplementationInterfaceService implements InterfaceService {

	@Override
	public String hello(String nom) {
		// TODO Auto-generated method stub
		return "hello "+nom;
	}

}
