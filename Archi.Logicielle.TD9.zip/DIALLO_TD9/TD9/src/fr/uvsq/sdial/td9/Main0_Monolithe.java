package fr.uvsq.sdial.td9;

public class Main0_Monolithe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		hello(args[0]);
	}
	
	public static void hello(String nom) {
		System.out.println("Hello "+nom);
	}
	
}
