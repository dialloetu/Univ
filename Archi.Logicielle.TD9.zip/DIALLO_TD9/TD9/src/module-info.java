module TD9 {
	exports fr.uvsq.sdial.td9;
	requires java.rmi;
}