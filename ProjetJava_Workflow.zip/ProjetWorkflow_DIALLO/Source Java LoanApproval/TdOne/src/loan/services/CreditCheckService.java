package loan.services;

import loan.status.CreditCheckStatus;
import loan.types.Address;
import loan.types.BorrowerInformation;

public class CreditCheckService {

	public CreditCheckStatus creditCheckServiceOp (BorrowerInformation applicantInformation){
		
		CreditCheckStatus status = new CreditCheckStatus(applicantInformation.getSSN().toString(), (applicantInformation.getSSN().startsWith("6") ? "Approved" : "Denied"));
		
		return status;
		
	}
	
	public CreditCheckStatus creditCheckServiceTwoOp (String name, String sSN, Address address){
		
		CreditCheckStatus status = new CreditCheckStatus(sSN, (sSN.startsWith("6") ? "Approved" : "Denied"));
		
		return status;
		
	}

}
