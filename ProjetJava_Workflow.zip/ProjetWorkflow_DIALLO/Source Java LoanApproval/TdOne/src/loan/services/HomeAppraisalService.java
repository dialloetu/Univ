package loan.services;

import loan.status.AppraisalStatus;
import loan.types.Address;
import loan.types.LoanDetails;

public class HomeAppraisalService {
	
	public AppraisalStatus AppraisalServiceOp (LoanDetails loanInformations){
		
		AppraisalStatus status = new AppraisalStatus(loanInformations.getSSN().toString(), 
				(Integer.parseInt(loanInformations.getLoan()) < Integer.parseInt(loanInformations.getPrice()) ? "Approved":"Denied"));
		
		return status;
		
	}
	
	public AppraisalStatus AppraisalServiceTwoOp (String sSN, String loanAmount, String homePrice, Address homeAddress){
			
			AppraisalStatus status = new AppraisalStatus(sSN.toString(), (Integer.parseInt(loanAmount) < Integer.parseInt(homePrice) ? "Approved":"Denied"));
			
			return status;
			
		}

}
