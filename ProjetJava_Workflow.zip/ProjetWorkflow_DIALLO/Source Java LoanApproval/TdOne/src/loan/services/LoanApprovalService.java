package loan.services;

import loan.status.AppraisalStatus;
import loan.status.CreditCheckStatus;
import loan.types.Address;
import loan.types.BorrowerInformation;
import loan.types.LoanDetails;

public class LoanApprovalService {

	public String loanApprovalService (BorrowerInformation applicantInformation, LoanDetails loanInformations){
			
			// Get status of CreditCheckService
			CreditCheckService creditCS = new CreditCheckService();
			CreditCheckStatus statusCreditCS =  creditCS.creditCheckServiceOp(applicantInformation);
			
			// Get status of HomeAppraisalService
			HomeAppraisalService homeAS = new HomeAppraisalService();
			AppraisalStatus statusHomeAS =  homeAS.AppraisalServiceOp(loanInformations);
			
			// Check Loan Approval Service
			String result = (statusCreditCS.getStatus().equals("Approved") && statusHomeAS.getStatus().equals("Approved") ? 
					"Mr/Ms " + applicantInformation.getName() + " , votre demande de pr�t a �t� accept�e :)" :
					"Mr/Ms " + applicantInformation.getName() + " , votre demande de pr�t a �t� rejet�e :( ");
			
			return result;
		}
	
	public String loanApprovalServiceTwo (String name, String sSN, Address address, String loanAmount, String homePrice, Address homeAddress){
		
		// Get status of CreditCheckService
		CreditCheckService creditCS = new CreditCheckService();
		CreditCheckStatus statusCreditCS =  creditCS.creditCheckServiceTwoOp(name, sSN, address);
		
		// Get status of HomeAppraisalService
		HomeAppraisalService homeAS = new HomeAppraisalService();
		AppraisalStatus statusHomeAS =  homeAS.AppraisalServiceTwoOp(sSN, loanAmount, homePrice, homeAddress);
		
		// Check Loan Approval Service
		String result = (statusCreditCS.getStatus().equals("Approved") && statusHomeAS.getStatus().equals("Approved") ? 
				"Mr/Ms " + name + " , votre demande de pr�t a �t� accept�e :)" :
				"Mr/Ms " + name + " , votre demande de pr�t a �t� rejet�e :( ");
		
		return result;
	}

}
