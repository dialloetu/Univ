package loan.types;

public class BorrowerInformation {

	private String Name;
	private String SSN;
	private Address address;

	
	public BorrowerInformation() {

	}

	public BorrowerInformation(String name, String sSN, Address address) { //
		this.Name = name;
		this.SSN = sSN;
		this.address = address;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		this.Name = name;
	}

	public String getSSN() {
		return SSN;
	}

	public void setSSN(String sSN) {
		this.SSN = sSN;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
}
