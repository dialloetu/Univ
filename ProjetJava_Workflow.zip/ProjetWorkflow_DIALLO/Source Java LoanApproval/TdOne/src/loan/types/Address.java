package loan.types;

public class Address {

	private String cityState;
	private String addr1;
	private String zip;
	private String phone;
	

	public Address(String cityState, String address, String zip, String phone) {
		
		this.cityState = cityState;
		this.addr1 = address;
		this.zip = zip;
		this.phone = phone;
	}
	
	
	public Address() {
		
	}


	public String getCity() {
		return cityState;
	}


	public void setCity(String cityState) {
		this.cityState = cityState;
	}


	public String getAddress() {
		return addr1;
	}


	public void setAddress(String address) {
		this.addr1 = address;
	}


	public String getZip() {
		return zip;
	}


	public void setZip(String zip) {
		this.zip = zip;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}

}
