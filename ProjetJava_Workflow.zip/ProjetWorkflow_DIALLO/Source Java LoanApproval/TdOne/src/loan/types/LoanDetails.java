package loan.types;

public class LoanDetails {
	
	private String SSN;
	private String LoanAmount;
	private String HomePrice;
	private Address HomeAddress;
	
	
	public LoanDetails() {
		
	}


	public LoanDetails(String sSN, String loanAmount, String homePrice, Address homeAddress ) {
		this.SSN = sSN;
		this.LoanAmount = loanAmount;
		this.HomePrice = homePrice;
	    this.HomeAddress = homeAddress;
	}


	public String getSSN() {
		return SSN;
	}


	public void setSSN(String sSN) {
		this.SSN = sSN;
	}


	public String getLoan() {
		return LoanAmount;
	}


	public void setLoan(String loanAmount) {
		this.LoanAmount = loanAmount;
	}


	public String getPrice() {
		return HomePrice;
	}


	public void setPrice(String homePrice) {
		this.HomePrice = homePrice;
	}

    
	public Address getAddress() {
		return HomeAddress;
	}


	public void setAddress(Address homeAddress) {
		this.HomeAddress = homeAddress;
	}

}
