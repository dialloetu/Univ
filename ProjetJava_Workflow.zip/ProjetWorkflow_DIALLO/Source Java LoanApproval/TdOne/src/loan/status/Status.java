package loan.status;

public class Status {
	
	private String status;
	private String SSN;
	
	public Status() {
		
	}

	public Status(String sSN, String status) {
		
		this.status = status;
		this.SSN = sSN;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSSN() {
		return SSN;
	}

	public void setSSN(String sSN) {
		SSN = sSN;
	}

}
