package loan.status;

public class CreditCheckStatus extends Status {
	
	public CreditCheckStatus() {
		super();
		
	}

	public CreditCheckStatus(String sSN, String status) {
		super(sSN, status);
		
	}


}
