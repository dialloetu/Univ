package loan.status;

public class AppraisalStatus  extends Status {
	
	public AppraisalStatus() {
		super();
		
	}

	public AppraisalStatus(String sSN, String status) {
		super(sSN, status);
		
	}

}
