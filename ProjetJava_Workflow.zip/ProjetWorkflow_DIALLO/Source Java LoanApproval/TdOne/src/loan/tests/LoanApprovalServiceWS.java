package loan.tests;

import java.rmi.RemoteException;

import loan.tests.LoanApprovalServiceStub;

public class LoanApprovalServiceWS {

	/**
	 * @param args
	 * @throws RemoteException 
	 */
	public static void main(String[] args) throws RemoteException {
		// TODO Auto-generated method stub
	
		//  Stub Object
		LoanApprovalServiceStub stub = new LoanApprovalServiceStub();
		
		// =========  Informations settings  ===============
		
		// Adress (cityState, address, zip, phone)
		LoanApprovalServiceStub.Address address = new LoanApprovalServiceStub.Address();
		address.setCity("Paris");
		address.setAddress("15 rue de bercy");
		address.setZip("75000");
		address.setPhone("0001020304");

		
		// Borrower Information (name, sSN, address)
		LoanApprovalServiceStub.BorrowerInformation borrowerInformation = new LoanApprovalServiceStub.BorrowerInformation();
		borrowerInformation.setName("John SMITH");
		borrowerInformation.setSSN("666777888");
		borrowerInformation.setAddress(address);
		
		// Loan Details (SSN, loanAmount, homePrice, homeAddress)
		LoanApprovalServiceStub.LoanDetails loanDetails = new LoanApprovalServiceStub.LoanDetails();
		loanDetails.setSSN(borrowerInformation.getSSN());
		loanDetails.setLoan("1900");
		loanDetails.setPrice("1200");
		loanDetails.setAddress(borrowerInformation.getAddress());

		// ========= Input and Output Messages ===============
		
		//  input Object
		LoanApprovalServiceStub.LoanApprovalService input = new LoanApprovalServiceStub.LoanApprovalService();
		input.setApplicantInformation(borrowerInformation);
		input.setLoanInformations(loanDetails);
		
		// Output Object 
		LoanApprovalServiceStub.LoanApprovalServiceResponse output = new LoanApprovalServiceStub.LoanApprovalServiceResponse();
		output = stub.loanApprovalService(input);
		
		// Output Message
		System.out.println(output.get_return());

	}

}
