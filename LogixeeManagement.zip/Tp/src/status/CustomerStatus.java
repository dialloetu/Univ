package status;


public class CustomerStatus extends Status {
	
	// private String idCustomer;
	
	public CustomerStatus(String status) {
		
		super(status);
		// this.idCustomer = idCustomer;
	}

	public CustomerStatus() {
		super();
	}


//	public String getIdCustomer() {
//		return idCustomer;
//	}
//
//	public void setIdCustomer(String newIdCustomer) {
//		this.idCustomer = newIdCustomer;
//	}
	
	
		
}
