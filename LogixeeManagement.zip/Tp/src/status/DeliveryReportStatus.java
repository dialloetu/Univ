package status;

public class DeliveryReportStatus extends Status {
	
	
	public DeliveryReportStatus() {
		super();
	}

	public DeliveryReportStatus(String status) {
		
		super(status);
	}	



}
