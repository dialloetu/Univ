package status;

public class ExpeditionPlanStatus extends Status {
	
	
	public ExpeditionPlanStatus() {
		super();
	}

	public ExpeditionPlanStatus(String status) {
		
		super(status);
	}




}
