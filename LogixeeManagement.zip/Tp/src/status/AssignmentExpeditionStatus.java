package status;

public class AssignmentExpeditionStatus extends Status {
	
	
	public AssignmentExpeditionStatus() {
		super();
	}

	public AssignmentExpeditionStatus(String status) {
		
		super(status);
	}




}
