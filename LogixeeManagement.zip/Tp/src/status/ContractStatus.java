package status;


public class ContractStatus extends Status {
	
	// private String idCustomer;
	
	public ContractStatus(String status) {
		
		super(status);
		// this.idCustomer = idCustomer;
	}

	public ContractStatus() {
		super();
	}


//	public String getIdCustomer() {
//		return idCustomer;
//	}
//
//	public void setIdCustomer(String newIdCustomer) {
//		this.idCustomer = newIdCustomer;
//	}
	
	
		
}
