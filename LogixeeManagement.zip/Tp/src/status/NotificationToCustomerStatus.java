package status;

public class NotificationToCustomerStatus extends Status {
	
	public NotificationToCustomerStatus() {
		super();
	}

	public NotificationToCustomerStatus(String status) {
		
		super(status);
	}	
	
	
}
