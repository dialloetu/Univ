package status;

public class DeliveryTourStatus extends Status {
	
	
	public DeliveryTourStatus() {
		super();
	}

	public DeliveryTourStatus(String status) {
		
		super(status);
	}	



}
