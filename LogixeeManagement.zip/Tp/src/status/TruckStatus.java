package status;

public class TruckStatus extends Status {

	public TruckStatus() {
		super();
	}

	public TruckStatus(String status) {
		super(status);
	}
	
}
