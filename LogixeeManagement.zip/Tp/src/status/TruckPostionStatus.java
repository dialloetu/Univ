package status;

public class TruckPostionStatus extends Status {

	public TruckPostionStatus() {
		super();
	}

	public TruckPostionStatus(String status) {
		super(status);
	}
	
}
