package status;

public class PlanDeliveryTourStatus extends Status {
	
	
	public PlanDeliveryTourStatus() {
		super();
	}

	public PlanDeliveryTourStatus(String status) {
		
		super(status);
	}	



}
