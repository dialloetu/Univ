package status;

public class NotificationToLogixeeStatus extends Status {
	
	public NotificationToLogixeeStatus() {
		super();
	}

	public NotificationToLogixeeStatus(String status) {
		
		super(status);
	}	
	
	
}
