package tp.services;

import status.NotificationToLogixeeStatus;
import tp.types.Expedition;

public class NotificationToLogixeeService {
	
	public NotificationToLogixeeStatus driverNotificationToLogixeeServiceOp (Expedition expedition, String messageFromTruckStatusService){
		
		NotificationToLogixeeStatus status = new NotificationToLogixeeStatus(expedition.getDriver().sentNotificationToLogixee(messageFromTruckStatusService, expedition.getRequest().getCustomer(), expedition.getLogixee()));
		
		return status;
		
	}

}
