package tp.services;

import status.DeliveryReportStatus;
import tp.types.DeliveryReport;
import tp.types.DeliveryTour;

public class DeliveryReportService {

	public DeliveryReportStatus deliveryReportServiceOp (DeliveryTour deliveryTour, String messageFromDeliveryTourStatus, DeliveryReport deliveryReport){
		 
		DeliveryReportStatus status = new DeliveryReportStatus(deliveryTour.getDriver().sentDeliveryReportToCustomer(messageFromDeliveryTourStatus, deliveryTour.getRequest().getCustomer(), deliveryTour.getLogixee(), deliveryReport));

		return status;
	}
	
}
