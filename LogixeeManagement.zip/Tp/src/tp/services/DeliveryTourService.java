package tp.services;

import status.DeliveryTourStatus;
import tp.types.DeliveryTour;

public class DeliveryTourService {

	public DeliveryTourStatus deliveryTourServiceOp (DeliveryTour deliveryTour){
		 
		DeliveryTourStatus status = new DeliveryTourStatus(deliveryTour.isFinish() == true ? "Finish":"Not Finish");

		return status;
	}
	
}
