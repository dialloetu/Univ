package tp.services;

import status.ExpeditionPlanStatus;
import tp.types.Expedition;

public class PlanExpeditionService {

	public ExpeditionPlanStatus planExpeditionServicOp (Expedition expedition){
		
		ExpeditionPlanStatus status = new ExpeditionPlanStatus(expedition.getArrival().getZip().toString().equals("") ? "NoPlanned":"Planned");

		return status;
	}
	
}
