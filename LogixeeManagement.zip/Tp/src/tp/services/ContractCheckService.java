package tp.services;


import status.ContractStatus;
import tp.types.CustomerRequest;
import tp.types.LogixeeManagement;

/**
 * @author diallo
 *
 */
public class ContractCheckService {

	/**
	 * @param customerRequest
	 * @param logixeeManagement
	 *
	 * @return status
	 */
	public ContractStatus contractCheckServiceOp (CustomerRequest customerRequest){

		ContractStatus status = new ContractStatus(customerRequest.getContract().getStatus().toString().equals("Valid") ? "Valid":"Invalid");

		return status;

	}

}
