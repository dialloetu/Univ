package tp.services;

import status.TruckStatus;
import tp.types.Expedition;

public class TruckStatusCheckService {
	
	public TruckStatus truckStatusCheckServiceOp (Expedition expedition){
		
		TruckStatus status = new TruckStatus(expedition.getDriver().getTruck().getProductList().size() > 0 && expedition.getDriver().getTruck().getPosition().getZip().toString().equals(expedition.getArrival().getZip().toString()) ? "LoadedAtCustomer":"EmptyAtCustomer");
		
		return status;
		
	}

}
