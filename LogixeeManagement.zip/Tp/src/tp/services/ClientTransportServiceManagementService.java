package tp.services;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

import tp.services.TransportServiceManagementServiceStub;


public class ClientTransportServiceManagementService {

	/**
	 * @param args
	 * @throws RemoteException 
	 */
	public static void main(String[] args) throws RemoteException {
		// TODO Auto-generated method stub
		
		//  Stub Object
		TransportServiceManagementServiceStub stub = new TransportServiceManagementServiceStub();
		
		// =========  Types Informations settings  ===============
		
		// Adress for LogixeeManagement
		TransportServiceManagementServiceStub.Address LogixeeAdress = new TransportServiceManagementServiceStub.Address();
		LogixeeAdress.setAddr1("15 Place de la victoire");
		LogixeeAdress.setCityState("Parais");
		LogixeeAdress.setZip("75005");
		
		// LogixeeManagement
		TransportServiceManagementServiceStub.LogixeeManagement logixee = new TransportServiceManagementServiceStub.LogixeeManagement();
		logixee.setAddress(LogixeeAdress);
		logixee.setName("Logixee Delivery Global Service");
		logixee.setPhone("093839383");
		
		// Adress for Customers
		TransportServiceManagementServiceStub.Address Customer1Adress = new TransportServiceManagementServiceStub.Address();
		Customer1Adress.setAddr1("2 Rue de la paix");
		Customer1Adress.setCityState("Rouen");
		Customer1Adress.setZip("76050");
		
		TransportServiceManagementServiceStub.Address Customer2Adress = new TransportServiceManagementServiceStub.Address();
		Customer2Adress.setAddr1("43 place de la republique");
		Customer2Adress.setCityState("Paris");
		Customer2Adress.setZip("75100");
		
		// Adrees for recipents
		TransportServiceManagementServiceStub.Address recipient1Adress = new TransportServiceManagementServiceStub.Address();
		recipient1Adress.setAddr1("2 Rue des achats");
		recipient1Adress.setCityState("Rouen");
		recipient1Adress.setZip("76250");
		
		TransportServiceManagementServiceStub.Address recipient2Adress = new TransportServiceManagementServiceStub.Address();
		recipient2Adress.setAddr1("94 Rue des rois");
		recipient2Adress.setCityState("Paris");
		recipient2Adress.setZip("75250");
		
		TransportServiceManagementServiceStub.Address recipient3Adress = new TransportServiceManagementServiceStub.Address();
		recipient3Adress.setAddr1("54 Rue des vendees");
		recipient3Adress.setCityState("Paris");
		recipient3Adress.setZip("75250");
		
		TransportServiceManagementServiceStub.Address recipient4Adress = new TransportServiceManagementServiceStub.Address();
		recipient4Adress.setAddr1("30 avenues des marchands ");
		recipient4Adress.setCityState("Rouen");
		recipient4Adress.setZip("76250");
		
		// Create customers 
		TransportServiceManagementServiceStub.Customer customer1Information = new TransportServiceManagementServiceStub.Customer();
		customer1Information.setName("Ubert Eats");
		customer1Information.setPhone("0102030405");
		customer1Information.setAddress(Customer1Adress);
		
		TransportServiceManagementServiceStub.Customer customer2Information = new TransportServiceManagementServiceStub.Customer();
		customer2Information.setName("Burger King");
		customer2Information.setPhone("0607034020");
		customer2Information.setAddress(Customer2Adress);
		
		// Create contracts
		TransportServiceManagementServiceStub.Contract contract1Information = new TransportServiceManagementServiceStub.Contract();
		contract1Information.setId(1);
		contract1Information.setStatus("Valid");
		
		TransportServiceManagementServiceStub.Contract contract2Information = new TransportServiceManagementServiceStub.Contract();
		contract2Information.setId(contract2Information.getId()+1);
		contract2Information.setStatus("Invalid");
		
		// Create CustomerRequests
		TransportServiceManagementServiceStub.CustomerRequest request1 = new TransportServiceManagementServiceStub.CustomerRequest();
		request1.setContract(contract2Information);
		request1.setCustomer(customer1Information);
		
		TransportServiceManagementServiceStub.CustomerRequest request2 = new TransportServiceManagementServiceStub.CustomerRequest();
		request2.setContract(contract1Information);
		request2.setCustomer(customer2Information);
		
		// Settings
		// input Object
		TransportServiceManagementServiceStub.TransportServiceManagementService input = new TransportServiceManagementServiceStub.TransportServiceManagementService();
		input.setCustomerRequest(request1);  // CustomertRequest 
		input.setLogixeeManagement(logixee); // logixeeMangament
		
		// Output Object
		TransportServiceManagementServiceStub.TransportServiceManagementServiceResponse output = new TransportServiceManagementServiceStub.TransportServiceManagementServiceResponse();
		output = stub.transportServiceManagementService(input);
		
		System.out.println(output.get_return());
		
		
		

	}

}
