package tp.services;

import status.AssignmentExpeditionStatus;
import tp.types.Expedition;

/**
 * @author diallo
 *
 */
public class CheckExpeditionAssignmentService {

	/**
	 * @param customerRequest
	 * @param logixeeManagement
	 *
	 * @return status
	 */
	public AssignmentExpeditionStatus planExpeditionServicOp (Expedition expedition){
		
		AssignmentExpeditionStatus status = new AssignmentExpeditionStatus(expedition.getDriver().getTruck() == null? "NoAssign":"Assign");

		return status;
	}

}
