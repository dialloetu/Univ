package tp.services;

import status.CustomerStatus;
import tp.types.CustomerRequest;
import tp.types.LogixeeManagement;

/**
 * @author diallo
 *
 */
public class CustomerCheckService {

	/**
	 * @param customerRequest
	 * @param logixeeManagement
	 *
	 * @return status
	 */
	public CustomerStatus customerCheckServiceOp (CustomerRequest customerRequest, LogixeeManagement logixeeManagement){

		CustomerStatus status = new CustomerStatus(logixeeManagement.customerExist(customerRequest.getCustomer()) ==  true ? "Exit":"NotExist");

		return status;

	}

}
