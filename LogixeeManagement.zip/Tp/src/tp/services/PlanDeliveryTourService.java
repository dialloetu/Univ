package tp.services;

import status.PlanDeliveryTourStatus;
import tp.types.DeliveryTour;

public class PlanDeliveryTourService {

	public PlanDeliveryTourStatus planDeliveryTourServiceOp (DeliveryTour deliveryTour){
		 
		PlanDeliveryTourStatus status = new PlanDeliveryTourStatus(deliveryTour.getArrival().getZip().toString().equals("") && (deliveryTour.getDriver().getTruck() == null) ? "NoPlannedAssigned":"PlannedAssigned");

		return status;
	}
	
}
