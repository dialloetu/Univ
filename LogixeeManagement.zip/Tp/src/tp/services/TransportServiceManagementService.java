package tp.services;

import java.util.ArrayList;
import java.util.Iterator;

import status.AssignmentExpeditionStatus;
import status.ContractStatus;
import status.CustomerStatus;
import status.DeliveryReportStatus;
import status.DeliveryTourStatus;
import status.ExpeditionPlanStatus;
import status.NotificationToCustomerStatus;
import status.NotificationToLogixeeStatus;
import status.PlanDeliveryTourStatus;
import status.TruckPostionStatus;
import status.TruckStatus;
import tp.types.CustomerRequest;
import tp.types.DeliveryReport;
import tp.types.DeliveryTour;
import tp.types.Driver;
import tp.types.Expedition;
import tp.types.LogixeeManagement;
import tp.types.Product;

public class TransportServiceManagementService {
	
	public String transportServiceManagementService(ArrayList<Product> listProduct, ArrayList<Driver> listDriver, CustomerRequest customerRequest, LogixeeManagement logixeeManagement, Expedition expedition, DeliveryTour deliveryTour, DeliveryReport deliveryReport) {
			
		// Get status of CustomerCheckService : customer exist and constract is valid ? "Approved":"Denied"
		CustomerCheckService customerCS = new CustomerCheckService();
		CustomerStatus statusCustomerCS =  customerCS.customerCheckServiceOp(customerRequest, logixeeManagement);
		
		// Get status of CustomerCheckService : customer exist and constract is valid ? "Approved":"Denied"
		ContractCheckService contractCS = new ContractCheckService();
		ContractStatus statusContractCS =  contractCS.contractCheckServiceOp(customerRequest);
				
		if(statusCustomerCS.getStatus().toString().equals("Exit") && statusContractCS.getStatus().toString().equals("Valid")){
			
			// Get Status for Plan exepedition and SetDriver to expedition 
			PlanExpeditionService planExpeditionS = new PlanExpeditionService();
			ExpeditionPlanStatus statusPlanExpeditionS =  planExpeditionS.planExpeditionServicOp(expedition);
			
			// Get Status for Assignment expedition to Driver
			CheckExpeditionAssignmentService assignmentExpeditionS = new CheckExpeditionAssignmentService();
			AssignmentExpeditionStatus statusAssignmentExpeditionS =  assignmentExpeditionS.planExpeditionServicOp(expedition);
			
			if (statusPlanExpeditionS.getStatus().toString().equals("Planned") && statusAssignmentExpeditionS.getStatus().toString().equals("Assign")) {
				
				// Driver at Customer office
				expedition.getDriver().getTruck().setPosition(customerRequest.getCustomer().getAddress());
				
				// Driver load his truck with customer product
				for (int i = 0; i < listProduct.size(); i++) {
					expedition.getDriver().getTruck().loadTruck(listProduct.get(i));
				}
				
				// Get status of TruckStatus : The Truck is loaded at customer or not
				TruckStatusCheckService truckStatusCS = new TruckStatusCheckService();
				TruckStatus truckCS =  truckStatusCS.truckStatusCheckServiceOp(expedition);
				
				if (truckCS.getStatus().toString().equals("LoadedAtCustomer")) {
					
					// expedition.getDriver().sentNotificationToLogixee(truckCS.getStatus().toString(), expedition.getRequest().getCustomer(), logixeeManagement);
					// Get status of Driver sent notifiction to Logixee | NotificationToLogixeeService
					NotificationToLogixeeService notificationToLogixeeS = new NotificationToLogixeeService();
					NotificationToLogixeeStatus statusNotificationToLogixeeS =  notificationToLogixeeS.driverNotificationToLogixeeServiceOp(expedition, truckCS.getStatus());
					
					// Get status of TruckPositionStatusCheckService : The truck is at the Logixee platform ? The truck is not at the Logixee platform
					TruckPositionStatusCheckService truckPositionStatusCS = new TruckPositionStatusCheckService();
					TruckPostionStatus truckPositionCS =  truckPositionStatusCS.truckPositionStatusCheckServiceOp(expedition);
					
					if (truckPositionCS.getStatus().toString().equals("TruckAtLogixeePlatform")) {
						
						// driver unload his truck at logixee platform
						for (int i = 0; i < expedition.getDriver().getTruck().getProductList().size(); i++) {
							expedition.getDriver().getTruck().unloadTruck(logixeeManagement);
						}
						
						// Get status of NotificationToCustomerService
						NotificationToCustomerService notificationToCustomerS = new NotificationToCustomerService();
						NotificationToCustomerStatus statusNotificationToCustomerS =  notificationToCustomerS.driverNotificationToCustomerServiceOp(expedition, truckPositionCS.getStatus());
						
						// Plan Delivery Tour
						ArrayList<Product> zipDeliveryTour = new ArrayList<Product>();
						ArrayList<Product> tmp_zipDeliveryTour = new ArrayList<Product>();
						zipDeliveryTour = expedition.getDriver().getTruck().getProductList();
						tmp_zipDeliveryTour = zipDeliveryTour;
						
						// processing
						for (Product produit : zipDeliveryTour){
							if (!tmp_zipDeliveryTour.contains(produit)) { 
								tmp_zipDeliveryTour.add(produit); 
				            } 
						}
						// Get number delivery tour
						int numberDeliveryTour = tmp_zipDeliveryTour.size();
						
						// create list of delivery tour's and assign
						ArrayList<DeliveryTour> listDeliveryTour = new ArrayList<DeliveryTour>();
						for (int i = 0; i < numberDeliveryTour; i++) {
							
								listDeliveryTour.add(new DeliveryTour("DeliveryTour n� "+i+"", expedition.getRequest(), listDriver.get(i), expedition.getLogixee(), tmp_zipDeliveryTour.get(i).getDeliveryAddress()));
								
						}
						
						// Get status of PlanDeliveryTourService : No Planned and No Assigned ? Planned and Assigned
						PlanDeliveryTourService planDeliveryTourS = new PlanDeliveryTourService();
						
						for (DeliveryTour tour : listDeliveryTour) {
							
							PlanDeliveryTourStatus statusPlanDeliveryTourS =  planDeliveryTourS.planDeliveryTourServiceOp(tour);
							
							if (statusPlanDeliveryTourS.getStatus().toString().equals("PlannedAssigned")){		
								
								// delivery and Finish
								tour.setFinish(true);
								
								// Get status of DeliveryTourService : Finish ? Not Finish
								DeliveryTourService deliveryTourS = new DeliveryTourService();
								DeliveryTourStatus statusDeliveryTourS =  deliveryTourS.deliveryTourServiceOp(tour);
								
								// if deliveryTour is Finish
								if (statusDeliveryTourS.getStatus().toString().equals("Finish")) {
													
									// Get status of DeliveryReportService
									DeliveryReportService deliveryReportS = new DeliveryReportService();
									DeliveryReportStatus statusDeliveryReportService =  deliveryReportS.deliveryReportServiceOp(tour, statusDeliveryTourS.getStatus().toString(), new DeliveryReport(tour));
									
									
								} else {
									// for delivery tour not finish
								}
							}
							else {
								// For not planned and asign
							}
						}
						
						
		
					}else {
						// For truck is not at logixee plateform
					}
					
					
				} else {
					// For truck not loaded at customer
				}
				
			} else {
				// For expeditio not planned and expedition not Assign
			}
			
		} else {
			// sutomer not exist and contract not valid
		}
		
		// Get status of PlanExpeditionService : No Planned and No Assigned ? Planned and Assigned
		
		// Return Logixee Report For Transport Service Management 
		String result ="";
		for (int i = 0; i < customerRequest.getCustomer().getMessage().size(); i++) {
			result += "\n == Message "+i+" == \n";
			result += customerRequest.getCustomer().getMessage().get(i).toString();
			result += "\n == Fin Message "+i+" == \n";
		}
		
		return result;
	}

}
