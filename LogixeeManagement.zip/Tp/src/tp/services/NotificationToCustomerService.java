package tp.services;

import status.NotificationToCustomerStatus;
import tp.types.Expedition;

public class NotificationToCustomerService {
	
	public NotificationToCustomerStatus driverNotificationToCustomerServiceOp (Expedition expedition, String messageFromTruckPositionStatusService){
		
		NotificationToCustomerStatus status = new NotificationToCustomerStatus(expedition.getDriver().sentMessageToCustomer(messageFromTruckPositionStatusService, expedition.getRequest().getCustomer(), expedition.getLogixee()));
		
		return status;
		
	}

}
