package tp.services;

import status.TruckPostionStatus;
import tp.types.Expedition;

public class TruckPositionStatusCheckService {
	
	public TruckPostionStatus truckPositionStatusCheckServiceOp (Expedition expedition){
		
		// Check if the truck is at the logi platform
		TruckPostionStatus status = new TruckPostionStatus(expedition.getDriver().getTruck().getPosition().getZip().toString().equals(expedition.getLogixee().getAddress().getZip().toString()) ? "TruckAtLogixeePlatform":"TruckNotAtLogixeePlatform");
		
		return status;
		
	}

}
