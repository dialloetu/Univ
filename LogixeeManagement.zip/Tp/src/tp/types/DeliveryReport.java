package tp.types;

public class DeliveryReport {
	
	private DeliveryTour deliveryTour;

	public DeliveryReport() {
		
	}

	public DeliveryReport(DeliveryTour deliveryTour) {
		this.deliveryTour = deliveryTour;
	}

	public DeliveryTour getDelivery() {
		return deliveryTour;
	}

	public void setDelivery(DeliveryTour deliveryTour) {
		this.deliveryTour = deliveryTour;
	}
	
	public String generateReport(){
		String report = ("===  DELIVERY REPORT  ===\n\n=   Expedition Id:   =\n" + this.deliveryTour.getName() + "=   Customer Name:   =\n"+this.deliveryTour.getRequest().getCustomer().getName()+"=   Driver Phone:   =\n"+this.deliveryTour.getDriver().getNameId()+"=   Truck ID�:   =\n"+this.deliveryTour.getDriver().getTruck().getNumberId()+"\n");
		report+="List of delivered products :\n ";
		for (int i = 0; i < this.deliveryTour.getDriver().getTruck().getProductList().size(); i++) {
			report+=" Delivery n� "+i+1+": "+this.deliveryTour.getDriver().getTruck().getProductList().get(i).getDeliveryAddress()+"\n ";
		}
		report+="\n===  END DELIVERY REPORT  ===\n";
		return report;
	}
	

}
