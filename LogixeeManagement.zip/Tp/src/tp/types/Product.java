package tp.types;

public class Product {
	
	
	private Address deliveryAddress;
	private boolean isDelivered;
	private boolean isSupported;

	public Product(Address address, boolean deliveryStatus, boolean supportedStatus) {
		
		this.deliveryAddress = address;
		this.isDelivered = deliveryStatus;
		this.isSupported = supportedStatus;
	}

	public Product() {
		
	}

	public Address getDeliveryAddress() {
		return this.deliveryAddress;
	}

	public void setDeliveryAddress(Address newDeliveryAddress) {
		this.deliveryAddress = newDeliveryAddress;
	}

	public boolean getDeliveryStatus() {
		return this.isDelivered;
	}

	public void setDeliveryStatus(boolean newDeliveryStatus) {
		this.isDelivered = newDeliveryStatus;
	}
	
	public boolean getSupportedStatus() {
		return this.isSupported;
	}

	public void setSupportedStatus(boolean newSupportedStatus) {
		this.isSupported = newSupportedStatus;
	}
	

}
