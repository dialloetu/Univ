package tp.types;

import java.util.ArrayList;

public class Truck {
	
	private String numberId;
	private ArrayList<Product> productList;
	private Address position;
	
	public Truck(String numberId, Address position) {
		
		this.numberId = numberId;
		this.productList = new ArrayList<Product>();
		this.position = position;
	}

	public String getNumberId() {
		return this.numberId;
	}

	public void setNumberId(String newNumberId) {
		this.numberId = newNumberId;
	}

	public ArrayList<Product> getProductList() {
		return this.productList;
	}

	public void setProductList(ArrayList<Product> newProductList) {
		this.productList = newProductList;
	}

	public Address getPosition() {
		return this.position;
	}

	public void setPosition(Address newPosition) {
		this.position = newPosition;
	}
	
	public void loadTruck (Product product) {
		
		// add this product to Truck  
		this.getProductList().add(product);

	}

	public boolean unloadTruck (LogixeeManagement logixee) {
		
		boolean status = false;
		
		if (this.productList.size() >= 0){
			for (int i = this.getProductList().size()-1 ; i >=0; i--) {
				
				// add last product from Truck to Plateform 
				logixee.getPlateform().add(this.getProductList().get(i));
				
				// delete this product from Truck  
				this.getProductList().remove(i);
			}
			status = true;
		}

		return status;

	}
	
	

}
