package tp.types;


public class Expedition {
	
	private String nameId;
	private CustomerRequest customerRequest;
	private LogixeeManagement logixeeManagement;
	private Driver driver;
	private Address startingAddress ;
	private Address arrivalAddress;
	
	public Expedition(String nameId, CustomerRequest customerRequest, Driver driver, LogixeeManagement logixeeManagement) {
		
		this.nameId = nameId;
		this.customerRequest = customerRequest;
		this.logixeeManagement = logixeeManagement;
		this.driver = driver;
		this.setStarting(this.logixeeManagement.getAddress());
		this.setArrival(this.getRequest().getCustomer().getAddress());
		
	}
	
	public Expedition() {
		
	}

	public String getName() {
		return this.nameId;
	}

	public void setName(String nameId) {
		this.nameId = nameId;
	}

	public Driver getDriver() {
		return this.driver;
	}

	public void setDriver(Driver conducteur) {
		this.driver = conducteur;
	}

	public Address getStarting() {
		return this.startingAddress;
	}

	public void setStarting(Address newStartingAddress) {
		this.startingAddress = newStartingAddress;
	}

	public Address getArrival() {
		return this.arrivalAddress;
	}

	public void setArrival(Address newArrivalAddress) {
		this.arrivalAddress = newArrivalAddress;
	}

	public CustomerRequest getRequest() {
		return this.customerRequest;
	}

	public void setRequest(CustomerRequest newCustomerRequest) {
		this.customerRequest = newCustomerRequest;
	}

	public LogixeeManagement getLogixee() {
		return this.logixeeManagement;
	}

	public void setLogixee(LogixeeManagement newLogixeeManagement) {
		this.logixeeManagement = newLogixeeManagement;
	}
	
	
}
