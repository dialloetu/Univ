package tp.types;

import java.util.ArrayList;

public class Driver {
	
	private String nameId;
	private String phone;
	private Truck truck;
	private ArrayList<String> messageSent;
	
	
	public Driver() {
		
	}


	public Driver(String nameId, String phone, Truck truck) {
		
		this.nameId = nameId;
		this.phone = phone;
		this.truck = truck;
		this.messageSent = new ArrayList<String>();
	}


	public String getNameId() {
		return this.nameId;
	}


	public void setNameId(String newNameId) {
		this.nameId = newNameId;
	}


	public String getPhone() {
		return this.phone;
	}


	public void setPhone(String newPhone) {
		this.phone = newPhone;
	}


	public Truck getTruck() {
		return this.truck;
	}


	public void setTruck(Truck newTruck) {
		this.truck = newTruck;
	}
	
	public String sentNotificationToLogixee(String truckStatus, Customer customer, LogixeeManagement logixee) {
		String status = "Your product is not supported";
		
		if (truckStatus.toString().equals("EmptyAtCustomer") || customer.equals(null)  || logixee.equals(null)) {
			status = "Your product is not supported";
		}
		else {   
			if (truckStatus.toString().equals("LoadedAtCustomer")) {
				// Customer received the messag
				customer.getMessage().add("Messag From Logixee driver: "+this.getPhone()+" | Content: "+truckStatus+".");
				// drive save copy of message
				this.messageSent.add("Message sent To customer phone: "+customer.getPhone()+" | Content: "+truckStatus+"."); 
				// Logixee Management is notified of support for the product.
				logixee.getMessage().add("Messag From driver Phone: "+this.getPhone()+" To Customer phone: "+customer.getPhone()+" | Content: "+truckStatus+".");
				// Status of message is updated
				status ="Your product is supported";
			}

		}
		return status;
	}
	
	public String sentMessageToCustomer(String truckPositionStatus, Customer customer, LogixeeManagement logixee) {
		String status = "Your product has not been supported on the logix platform";
		
		if (truckPositionStatus.toString().equals("TruckNotAtLogixeePlatform") || customer.equals(null)  || logixee.equals(null) || this.truck.getProductList().size() > 0) {
			status = "Your product has not been supported on the logix platform";
		}
		else {   
			if (truckPositionStatus.toString().equals("TruckAtLogixeePlatform") && (this.truck.unloadTruck(logixee) == true)) {
				// Logixee Management received the messag
				logixee.getMessage().add("Messag From driver Phone: "+this.getPhone()+ " | Content: The "+ customer.getName() +" customer product has been unload on the logixee platform.");
				// Customer is notified of support for the product at the logixee plateform. 
				customer.getMessage().add("Messag From LogixeeManagement phone : "+logixee.getPhone()+ " | Content: Your product has been supported on the logixee platform.");
				// drive save copy of message
				this.messageSent.add("Message sent To LogixeeManagement phone: "+logixee.getPhone()+ " | Content: The "+ customer.getName() +" customer product has been unload on the logixee platform.");
				// Status of message is updated
				status ="Your product has been supported on the logixee platform";
			}

		}
		return status;
	}
	
	public String sentDeliveryReportToCustomer(String deliveryTourStatus, Customer customer, LogixeeManagement logixee, DeliveryReport deliveryReport) {
		String status = "Delivery report not generated";
		
		if (deliveryTourStatus.toString().equals("Not Finish") || customer.equals(null)  || logixee.equals(null) || deliveryReport.equals(null)) {
			status += ".";
		}
		else {   
			if (deliveryTourStatus.toString().equals("Finish")) {
				// Logixee Management received the notification
				logixee.getMessage().add("Delivery Report From driver Phone: "+this.getPhone()+ " | Content: "+deliveryReport.generateReport()+".");
				// Customer is received report. 
				customer.getMessage().add("Delivery Report From LogixeeManagement phone : "+logixee.getPhone()+ " | Content: "+deliveryReport.generateReport()+".");
				// drive save copy of report
				this.messageSent.add("Delivery Report sent To Customer phone: "+customer.getPhone()+ " | Content: "+deliveryReport.generateReport()+".");
				// Status of message is updated
				status ="Delivery report generated";
			}

		}
		return status;
	}
	
	
	
	
	
	
	
	

}
