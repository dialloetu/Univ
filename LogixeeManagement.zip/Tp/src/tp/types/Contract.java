package tp.types;

public class Contract {
	
	private int id;
	private String status;

	
	public Contract() {
		
	}


	public Contract(int id, String statusContract) {
		
		this.id = id;
		this.status = statusContract;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getStatus() {
		return this.status;
	}


	public void setStatus(String newStatusContract) {
		this.status = newStatusContract;
	}



	

}
