package tp.types;

public class Customer extends Organization {
	
	public Customer(String name, Address address, String phone) {
		
		super(name, address, phone);
		// super.setMessageReceived(new ArrayList<String>());
	}

	public Customer() {
		super();
	}

		

}
