package tp.types;

import java.util.ArrayList;

public class Organization {
	
	private String name;
	private Address address;
	private String phone;
	private ArrayList<String> messageReceived;
	
	public Organization(String name, Address address, String phone) {
		
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.setMessage(new ArrayList<String>());
	}

	public Organization() {
		
	}

	public String getName() {
		return this.name;
	}

	public void setName(String newName) {
		this.name = newName;
	}

	public Address getAddress() {
		return this.address;
	}

	public void setAddress(Address newAddress) {
		this.address = newAddress;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String newPhone) {
		this.phone = newPhone;
	}

	public ArrayList<String> getMessage() {
		return messageReceived;
	}

	public void setMessage(ArrayList<String> messageReceived) {
		this.messageReceived = messageReceived;
	}
	
	
	
	
	
	
	
	
	
	
	

}
