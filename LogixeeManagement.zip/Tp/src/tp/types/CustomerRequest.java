package tp.types;

public class CustomerRequest {
	
	private Customer customerId;
	private Contract contractId;
	
	public CustomerRequest(Customer customerId, Contract contractId) {
		
		this.customerId = customerId;
		this.contractId = contractId;
	}

	public CustomerRequest() {
		
	}

	public Customer getCustomer() {
		return customerId;
	}

	public void setCustomer(Customer newCustomerId) {
		this.customerId = newCustomerId;
	}

	public Contract getContract() {
		return contractId;
	}

	public void setContract(Contract newContractId) {
		this.contractId = newContractId;
	}

	

}
