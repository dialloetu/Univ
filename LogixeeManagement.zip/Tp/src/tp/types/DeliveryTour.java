package tp.types;

public class DeliveryTour extends Expedition {

	private boolean isFinish;
	
	public DeliveryTour() {
		super();
		
	}

	public DeliveryTour(String nameId, CustomerRequest customerRequest, Driver driver, LogixeeManagement logixeeManagement, Address finalAdress) {
		super(nameId, customerRequest, driver, logixeeManagement);
		super.setStarting(logixeeManagement.getAddress());
		super.setArrival(finalAdress);
		this.setFinish(false);
	}

	public boolean isFinish() {
		return isFinish;
	}

	public void setFinish(boolean newStatus) {
		this.isFinish = newStatus;
	}


	
	
	
	
	
	
	

}
