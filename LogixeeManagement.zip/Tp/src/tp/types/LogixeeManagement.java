package tp.types;

import java.util.ArrayList;

public class LogixeeManagement extends Organization {

	private  ArrayList<Customer> customerDatabase;
	private  ArrayList<Product> plateformStockageProduct;
	
	public LogixeeManagement() {
		super();
	}
	
	public LogixeeManagement(String name, Address address, String phone) {
		
		super(name, address, phone);
		// super.setMessageReceived(new ArrayList<String>());
		this.customerDatabase = new ArrayList<Customer>();
		this.plateformStockageProduct = new ArrayList<Product>(); 
	}
	

	public ArrayList<Customer> getDatabase() {
		return customerDatabase;
	}

	public void setDatabase(ArrayList<Customer> customerDatabase) {
		this.customerDatabase = customerDatabase;
	}
	
	public boolean customerExist(Customer customer){
		return this.customerDatabase.contains(customer);
	}

	public ArrayList<Product> getPlateform() {
		return plateformStockageProduct;
	}

	public void setPlateform(ArrayList<Product> plateformStockageProduct) {
		this.plateformStockageProduct = plateformStockageProduct;
	}

}
