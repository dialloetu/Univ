package tp.types;

public class Address {
	
	private String city;
	private String address;
	private String zip;
	

	public Address(String city, String address, String zip) {
		
		this.city = city;
		this.address = address;
		this.zip = zip;
	}
	
	
	public Address() {
		
	}


	public String getCity() {
		return city;
	}


	public void setCity(String cityState) {
		this.city = cityState;
	}


	public String getAddr() {
		return address;
	}


	public void setAddr(String addr1) {
		this.address = addr1;
	}


	public String getZip() {
		return zip;
	}


	public void setZip(String zip) {
		this.zip = zip;
	}
	
	

}
